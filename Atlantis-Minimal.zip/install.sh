######
# Checking for installation environment
if [ $BOOTMODE = true ]; then
    ui_print "- Finding root path"
    ROOT="$(find "$(magisk --path)" -maxdepth 2 -type d -name "mirror" -print)"
    ui_print "  Path: $ROOT"
else
    unset ROOT
fi

######
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true
dex2oat_mode="everything"

#Remove
rm -rf data/media/0/AtlantisTweak

on_install() {
sleep 2
ui_print " 
 ▀▀█▀▀ █░░▒█ █▀▀▀ █▀▀██░▄▀ █▀▀▀█
 ░▒█░░ █▒█▒█ █▀▀▀ █▄▄█ █▀▄░ ▀▀▀▄▄
 ░▒█░░ █▄▀▄█ █▄▄▄ █░▒█ █░▒█ █▄▄▄█"
sleep 2
ui_print "▓ 𝘿𝙀𝙑𝙄𝘾𝙀 : $(getprop ro.product.product.marketname)"
sleep 2
ui_print "▓ 𝘾𝙊𝘿𝙀𝙉𝘼𝙈𝙀 : $(getprop ro.build.product)"
sleep 2
ui_print "▓ 𝘽𝙍𝘼𝙉𝘿 : $(getprop ro.product.system.manufacturer)"
sleep 2
ui_print "▓ 𝙋𝙍𝙊𝘾𝙀𝙎𝙎𝙊𝙍 : $(getprop Build.BRAND)"
sleep 2
ui_print "▓ 𝘾𝙋𝙐 : $(getprop ro.hardware)"
sleep 2
ui_print "▓ 𝘼𝙉𝘿𝙍𝙊𝙄𝘿 : $(getprop ro.build.version.release)"
sleep 2
ui_print "▓ 𝙆𝙀𝙍𝙉𝙀𝙇 : $(uname -r)"
sleep 2
ui_print "▓ 𝙍𝘼𝙈 : $(free | grep Mem |  awk '{print $2}')"
sleep 2
  ui_print "- Extracting Tweaks Script"
  sleep 4
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'eol/*' -d $MODPATH >&2
  cp $MODPATH/eol/* $MODPATH/
  rm -rf $MODPATH/eol
  pm install $MODPATH/toast.apk
  sleep 1
  rm $MODPATH/toast.apk
unzip -o "$ZIPFILE" 'LICENSE' -d $MODPATH >&2
}

set_permissions() {
  sleep 2
  set_perm_recursive $MODPATH 0 0 0777 0777
  }
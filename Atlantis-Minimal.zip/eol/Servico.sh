#!/bin/sh
MODDIR=${0%/*}
while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; done
AI &
sda
stop logd
stop perfd
stop tcpdump
stop cnss_diag
stop statsd
stop traced
stop idd-logreader
stop idd-logreadermain
stop vendor.perfservice
stop miuibooster
stop system_perf_init
$MODDIR/Atlantis-Core

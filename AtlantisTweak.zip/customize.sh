SKIPUNZIP=1
[[ "$BOOTMODE" == "false" ]] && abort "Atlantis Do Not Support Flash on Recovery, Please Flash this Module on Your Magisk." 
# Checking for installation environment
if [ $BOOTMODE = true ]; then
    ui_print "- Finding root path"
    ROOT="$(find "$(magisk --path)" -maxdepth 2 -type d -name "mirror" -print)"
    ui_print "  Path: $ROOT"
else
    unset ROOT
fi
rm /data/media/0/log
rm /data/media/0/logz
rm /data/media/0/log2
rm /data/media/0/log3
# make sure variables are correct regardless of Magisk or recovery sourcing the script
busybox() {
mkdir /data/adb/modules/Builtin-BusyBox/
unzip -o "$ZIPFILE" 'bobol' -d $MODPATH >&2
tar -xf $MODPATH/bobol -C /data/adb/modules/Builtin-BusyBox/
rm $MODPATH/bobol
}
if [[ -e /storage/emulated/0/log_tmp ]]
then
rm /storage/emulated/0/log_tmp
fi
clear
ui_print "
 ▄▄▄· ▄▄▄▄▄  ▄▄▌   ▄▄▄·  ▐ ▄ ▄▄▄▄▄  ▪  .▄▄ · 
▐█ ▀█ •██    ██•  ▐█ ▀█ •█▌▐█•██    ██ ▐█ ▀. 
▄█▀▀█  ▐█.▪  ██▪  ▄█▀▀█ ▐█▐▐▌ ▐█.▪  ▐█·▄▀▀▀█▄
▐█ ▪▐▌ ▐█▌·  ▐█▌▐▌▐█ ▪▐▌██▐█▌ ▐█▌·  ▐█▌▐█▄▪▐█
 ▀  ▀  ▀▀▀   .▀▀▀  ▀  ▀ ▀▀ █▪ ▀▀▀   ▀▀▀ ▀▀▀▀ 
"
sleep 1
ui_print "▓ 𝘿𝙀𝙑𝙄𝘾𝙀 : $(getprop ro.product.model)"
ui_print "▓ 𝘼𝙉𝘿𝙍𝙊𝙄𝘿 : $(getprop ro.build.version.release)"
ui_print "▓ 𝙆𝙀𝙍𝙉𝙀𝙇 : $(uname -r)"
ui_print "▓ 𝙍𝘼𝙈 : $(free | grep Mem |  awk '{print $2}')"
rm -rf /data/media/0/AtlantisTweak
rm /data/media/0/Atlantis.log
rm -rf /data/adb/modules_update/Z907L
rm -rf /data/adb/modules/sleep
rm -rf /data/adb/modules/aaddon
rm -rf /data/adb/modules/gunlocker
rm -rf /data/adb/module/autocpu
rm -rf /data/adb/modules/angle
  unzip -o "$ZIPFILE" 'module.prop' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'modulep.prop' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'system.prop' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'AIO/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'busybox.sh' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'servicen.sh' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'Sleep' -d $MODPATH >&2
mkdir -p /data/adb/modules/kcal/
mv $MODPATH/modulep.prop /data/adb/modules/kcal/module.prop
mv $MODPATH/servicen.sh /data/adb/modules/kcal/service.sh
sleep 1
# The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
  . $TMPDIR/addon/Volume-Key-Selector/preinstall.sh

  R='\e[01;91m' > /dev/null 2>&1;
  G='\e[01;92m' > /dev/null 2>&1;
  ui_print ""
ui_print "- 𝘾𝙝𝙤𝙤𝙨𝙚 𝙔𝙤𝙪𝙧 𝘾𝙤𝙣𝙛𝙞𝙜"
sleep 0.2
ui_print "  [𝙑𝙤𝙡𝙪𝙢𝙚 ➕ ] 𝙉𝙚𝙭𝙩"
ui_print "  [𝙑𝙤𝙡𝙪𝙢𝙚 ➖ ] 𝙄𝙣𝙨𝙩𝙖𝙡𝙡"
ui_print "   "
ui_print "   "
 ui_print "- Choose Atlantis Tweak Base Code️"
  ui_print "    1. Normal "
  ui_print "    2. Extended (THIS CODE IS BETTER, BUT CAN CAUSE"
  ui_print "       BOOTLOOP FOR SOME DEVICES)."
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
SR=1
while true; do
	ui_print "  $SR"
	if $VKSEL; then
		SR=$((SR + 1))
	else 
		break
	fi
	if [ $SR -gt 2 ]; then
		SR=1
	fi
done
#
case $SR in
	1 ) FCTEXTAD0="✅ Normal Version Has Been Installed Succesfully.";
unzip -o "$ZIPFILE" '02' -d $MODPATH >&2	
tar -xf $MODPATH/02 -C $MODPATH/
rm $MODPATH/02
touch /data/media/0/log2 ;;
	2 ) FCTEXTAD0="✅ Extended Version Has Been Installed Succesfully. "; unzip -o "$ZIPFILE" '01' -d $MODPATH >&2	
tar -xf $MODPATH/01 -C $MODPATH/
rm $MODPATH/01;;
esac
sleep 1
ui_print "- $FCTEXTAD0 "
ui_print "   "
ui_print "   "
  ui_print "- Do You Want To Unlock All Game Graphics + FPS?"
 ui_print "- [Include Mobile Legends]️"
  ui_print "    1. Yes. "
  ui_print "    2. No. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
SR=1
while true; do
	ui_print "  $SR"
	if $VKSEL; then
		SR=$((SR + 1))
	else 
		break
	fi
	if [ $SR -gt 2 ]; then
		SR=1
	fi
done
#
case $SR in
	1 ) FCTEXTAD0="✅ Graphics Unlocker Has Been Installed Succesfully.";
source $MODPATH/setup.sh
    apply_config
    rm $MODPATH/setup.sh  
unzip -o "$ZIPFILE" 'Reset' -d $MODPATH >&2
mkdir -p /data/adb/modules/gunlocker
tar -xf $MODPATH/Reset -C /data/adb/modules/gunlocker
mv $MODPATH/gunlocker/ /data/adb/modules/gunlocker
;;
	2 ) FCTEXTAD0="❌ 𝑆𝑘𝑖𝑝. ";
	rm $MODPATH/setup.sh ;;
esac
sleep 1
ui_print "- $FCTEXTAD0 "
ui_print "   "
ui_print "   "
ui_print "- Do You Want QTI Memorry Optimization For Better"
ui_print "- RAM Management And CPU Usage?️"
  ui_print "    1. Yes I Want. "
  ui_print "    2. No I Dont. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 2 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD2=" ✓You Choose Yes."; unzip -o "$ZIPFILE" 'Addon' -d $MODPATH >&2
	mkdir -p /data/adb/modules/aaddon
unzip -o "$ZIPFILE" 'module-torso.prop' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'system-torso/*' -d $MODPATH >&2
tar -xf $MODPATH/Addon -C $MODPATH/system-torso/bin
mv $MODPATH/module-torso.prop /data/adb/modules/aaddon/module.prop
mv $MODPATH/system-torso/ /data/adb/modules/aaddon/system
mv $MODPATH/service.sh /data/adb/modules/aaddon/service.sh; FCTEXTAD2a="✅ QTI Memorry Has Been Installed Succesfully."; ;;
	2 ) FCTEXTAD2=""; FCTEXTAD2a="❌ 𝑆𝑘𝑖𝑝.";;
esac
sleep 1
ui_print "- $FCTEXTAD2a "
ui_print "   "
ui_print "   "
reon3() {
  ui_print "- Userspace Governor Detected."
 ui_print "- Do You Want To Use Userspace Governor Tweak?"
  ui_print "    1. No, I Want to Use Default Governor. "
  ui_print "    2. Yes, I Want "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
SR=1
while true; do
	ui_print "  $SR"
	if $VKSEL; then
		SR=$((SR + 1))
	else 
		break
	fi
	if [ $SR -gt 2 ]; then
		SR=1
	fi
done
#
case $SR in
	1 ) FCTEXTAD0="✅ Okay."; rm -rf /data/adb/modules/autocpu;;
	2 ) FCTEXTAD0="✅ Userspace CPU Governor Tweak Has Been Installed Succesfully. ";mkdir -p /data/adb/modules/autocpu
unzip -o "$ZIPFILE" 'Auto' -d $MODPATH >&2
tar -xf $MODPATH/Auto -C /data/adb/modules/autocpu/;;
esac
sleep 1
ui_print "- $FCTEXTAD0 "
}
if grep -q userspace /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors; then
    reon3
fi
testo() {
ui_print "   "
ui_print "   "
  ui_print "- Do You Want To Flash Disable Syslimiter To"
 ui_print "- Unlock Max CPU?"
  ui_print "    1. Yes. "
  ui_print "    2. No. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
SR=1
while true; do
	ui_print "  $SR"
	if $VKSEL; then
		SR=$((SR + 1))
	else 
		break
	fi
	if [ $SR -gt 2 ]; then
		SR=1
	fi
done
#
case $SR in
	1 ) FCTEXTAD0="✅ Disable Syslimiter Has Been Installed Succesfully.";
rm -rf /data/adb/modules/syslimiter
mkdir -p /data/adb/modules/syslimiter
unzip -o "$ZIPFILE" 'SYS' -d $MODPATH >&2
tar -xf $MODPATH/SYS -C /data/adb/modules/syslimiter/
chmod -R 0777 /data/adb/modules/syslimiter
rm $MODPATH/SYS
;;
	2 ) FCTEXTAD0="❌ 𝑆𝑘𝑖𝑝. "; rm -rf /data/adb/modules/syslimiter ;;
esac
sleep 1
ui_print "- $FCTEXTAD0 "
}
if [[ -e /data/media/0/log2 ]]
then
testo
fi
ui_print "   "
ui_print "   "
ui_print "- Do You Want To Inject Rendering Angle?️"
  ui_print "    1. Normal Angle "
  ui_print "    2. Auto Angle. [AUTO ENABLE WHEN OPEN THE GAMES]"
               
  ui_print "    3. No I Dont. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 3 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD3=" ✓You Choose Yes."; 
	unzip -o "$ZIPFILE" 'Angle' -d $MODPATH >&2
	mkdir -p /data/adb/modules/angle
tar -xf $MODPATH/Angle -C /data/adb/modules/angle
rm $MODPATH/Angle; FCTEXTAD2b="✅ Rendering Angle Injected Successfully."; ;;
	2 ) FCTEXTAD3=" ✓You Choose Yes."; 
	unzip -o "$ZIPFILE" 'Anglez' -d $MODPATH >&2
	mkdir -p /data/adb/modules/angle
tar -xf $MODPATH/Anglez -C /data/adb/modules/angle
rm $MODPATH/Anglez ; FCTEXTAD2b="✅ Auto Rendering Angle Successfully Installed."; ;;
	3 ) FCTEXTAD3=""; FCTEXTAD2b="❌ 𝑆𝑘𝑖𝑝.";;
esac
sleep 1
ui_print "- $FCTEXTAD2b "
ui_print "   "
ui_print "   "
ui_print "- Do You Want To Activating GMS Doze?"
  ui_print "    1. Yes I Want. "
  ui_print "    2. No I Dont. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 2 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD3=" ✓You Choose Yes.";ui_print "- Please Wait..."
 unzip -o "$ZIPFILE" 'gms.sh' -d $MODPATH >&2
source $MODPATH/gms.sh
PATCH_SX && PATCH_MX 
rm $MODPATH/gms.sh ; FCTEXTAD2b="✅ GMS Doze Installed Successfully."; ;;
	2 ) FCTEXTAD3=""; FCTEXTAD2b="❌ 𝑆𝑘𝑖𝑝.";;
esac
sleep 1
	unzip -o "$ZIPFILE" 'Servico.sh' -d $MODPATH >&2
	mv $MODPATH/Servico.sh $MODPATH/service.sh
ui_print "- $FCTEXTAD2b "
ui_print "   "
ui_print "   "
ui_print "- Do You Want To Use CPU Runtime Breaker to Block System CPU Limiter?"
  ui_print "    1. Yes I Want. "
  ui_print "    2. No I Dont. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 2 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD3=" ✓You Choose Yes.";ui_print "- Please Wait..."
 unzip -o "$ZIPFILE" 'cpur' -d $MODPATH >&2
 rm -rf /data/adb/modules/cpu_runtime/
mkdir -p /data/adb/modules/cpu_runtime/
tar -xf $MODPATH/cpur -C /data/adb/modules/cpu_runtime/
chmod -R 0777 /data/adb/modules/cpu_runtime/
rm $MODPATH/cpur ; FCTEXTAD2b="✅ CPU Runtime Breaker Installed Successfully.
- Check Your Internal Storage in /Android/CPU_Runtime/game_list.txt to add more games."; ;;
	2 ) FCTEXTAD3=""; FCTEXTAD2b="❌ 𝑆𝑘𝑖𝑝.";;
esac
sleep 1
ui_print "- $FCTEXTAD2b "
ui_print "   "
ui_print "   "
ui_print "- Do You Want To Activating Activity Manager MOD For"
ui_print "- Better CPU Composition?"
  ui_print "    1. Yes I Want. "
  ui_print "    2. No I Dont. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 2 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD3=" ✓You Choose Yes."; unzip -o "$ZIPFILE" 'Activity' -d $MODPATH >&2 ; FCTEXTAD2b="✅ Activity Manager MOD Installed Successfully."; ;;
	2 ) FCTEXTAD3="";sed -i '3d' $MODPATH/service.sh ; FCTEXTAD2b="❌ 𝑆𝑘𝑖𝑝.";;
esac
sleep 1
ui_print "- $FCTEXTAD2b "
ui_print "   "
ui_print "   "
# Zram
ui_print "- ZRAM Options. "
ui_print "    1. Disable ZRAM"
ui_print "    2. 1024MB"
ui_print "    3. 1536MB"
ui_print "    4. 2048MB"
ui_print "    5. 2560MB"
ui_print "    6. 3072MB"
ui_print "    7. 4096MB"
ui_print "    8. 5120MB"
ui_print "    9. 6144MB"
ui_print "    10. Skip"
ui_print ""
ui_print "    𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
D=1
while true; do
    ui_print "    $D"
    if $VKSEL; then
        D=$((D + 1))
    else
        break
    fi
    if [ $D -gt 10 ]; then
        D=1
    fi
done
case $D in
    1 ) TEXT4="Disable"; sed -i '/#change_zram/s/.*/disable_zram/' $MODPATH/service.sh;;
    2 ) TEXT4="1024MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=1025M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    3 ) TEXT4="1536MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=1537M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    4 ) TEXT4="2048MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=2049M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    5 ) TEXT4="2560MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=2561M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    6 ) TEXT4="3072MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=3073M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    7 ) TEXT4="4096MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=4097M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    8 ) TEXT4="5120MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=5121M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    9 ) TEXT4="6144MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=6145M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    10 ) TEXT4="❌ 𝑆𝑘𝑖𝑝.";;
esac
ui_print "    $TEXT4"
ui_print ""
ui_print ""
# Swap ram
ui_print "  Swap RAM Options."
ui_print "    1. 1024MB"
ui_print "    2. 1536MB"
ui_print "    3. 2048MB"
ui_print "    4. 2560MB"
ui_print "    5. 3072MB"
ui_print "    6. 4096MB"
ui_print "    7. 5120MB"
ui_print "    8. 6144MB"
ui_print "    9. Skip"
ui_print ""
ui_print "    𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
E=1
while true; do
    ui_print "    $E"
    if $VKSEL; then
        E=$((E + 1))
    else
        break
    fi
    if [ $E -gt 9 ]; then
        E=1
    fi
done
ui_print "    Selected: $E"
case $E in
    1 ) TEXT5="1024MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=1048576/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    2 ) TEXT5="1536MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=1572864/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    3 ) TEXT5="2048MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=2097152/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    4 ) TEXT5="2560MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=2621440/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    5 ) TEXT5="3072MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=3145728/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    6 ) TEXT5="4096MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=4194304/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    7 ) TEXT5="5120MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=5242880/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    8 ) TEXT5="6144MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=6291456/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
        9 ) TEXT5="❌ 𝑆𝑘𝑖𝑝.";;
esac
ui_print "    $TEXT5"
ui_print ""
ui_print ""
ui_print "- Do You Want To Disable/Moded Thermal?"
  ui_print "    1. Yes I Want. "
  ui_print "    2. No I Dont. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 2 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD2=" ✓You Choose Yes."; touch /data/media/0/logz
	rm -rf /data/adb/modules/atlantis_thermods/
	mkdir -p /data/adb/modules/atlantis_thermods/
	unzip -o "$ZIPFILE" 'Thermal' -d /data/adb/modules/atlantis_thermods/ >&2
	tar -xf /data/adb/modules/atlantis_thermods/Thermal -C /data/adb/modules/atlantis_thermods/
	rm /data/adb/modules/atlantis_thermods/Thermal
	unzip ; FCTEXTAD2a="✅ Okay."; ;;
	2 ) FCTEXTAD2=""; FCTEXTAD2a="❌ 𝑆𝑘𝑖𝑝.";;
esac
sleep 1
ui_print "- $FCTEXTAD2a "
ui_print "   "
ui_print "   "
zegon() {
ui_print "- Select Thermal Mods"
  ui_print " 1. ᴛʜᴇʀᴅᴏɢꜱ
- ᴅɪꜱᴀʙʟᴇ ᴀʟʟ ᴛʜᴇʀᴍᴀʟ ᴀɴᴅ ᴛʜᴇɴꜱᴏʀ ᴡɪᴛʜᴏᴜᴛ ʀᴇᴘʟᴀᴄɪɴɢ 
- ᴀɴʏ ꜰɪʟᴇꜱ "
ui_print ""
  ui_print " 2. ᴛʜᴇʀᴍᴏᴅꜱ
- ᴘᴜʀᴇ ᴛʜᴇʀᴍᴏᴅꜱ.
- ʙᴀᴛᴛᴇʀʏ ᴄᴏᴏʟɪɴɢ ᴀᴛ 47°ᴄ ʟɪᴍɪᴛ ᴀᴛ 49°ᴄ
- ᴄᴘᴜ ᴄᴏᴏʟɪɴɢ ᴀᴛ 66°ᴄ ʟɪᴍɪᴛ ᴀᴛ 70°ᴄ"
ui_print ""
  ui_print " 3. ᴀᴇᴛʜᴇʀ
  (CAN CAUSED BOOTLOOP FOR SOME REASON)
- ᴅɪꜱᴀʙʟᴇ ᴀʟʟ ᴛʜᴇʀᴍᴀʟ ᴀɴᴅ ᴛʜᴇɴꜱᴏʀ + ʀᴇᴘʟᴀᴄᴇ ᴀʟʟ ᴛʜᴇʀᴍᴀʟ ᴄᴏɴꜰɪɢ ᴀɴᴅ ᴅɪꜱᴀʙʟᴇ ᴠᴇɴᴅᴏʀ ᴛʜᴇʀᴍᴀʟ "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝗵𝗲𝗿𝗺𝗮𝗹 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
tar -xf $MODPATH/Prop -C $MODPATH/
rm $MODPATH/Prop
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 3 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD0="✅ Therdogs Successfully Installed.";
rm -rf /data/adb/modules/atlantis_thermods/system
mv /data/adb/modules/atlantis_thermods/systeml /data/adb/modules/atlantis_thermods/system
rm /data/adb/modules/atlantis_thermods/@Z907L
 ;;
	2 ) FCTEXTAD0="✅ Thermods Successfully Installed. "; 	unzip -o "$ZIPFILE" 'Atlantis' -d $MODPATH >&2
	rm /data/adb/modules/atlantis_thermods/@Z907L
	rm /data/adb/modules/atlantis_thermods/local
rm -rf /data/adb/modules/atlantis_thermods/system
rm -rf /data/adb/modules/atlantis_thermods/systeml;;
    3 ) FCTEXTAD0="✅ Aether Successfully Installed. "; rm -rf /data/adb/modules/atlantis_thermods/systeml;;
    
esac
sleep 1
ui_print "- $FCTEXTAD0 "
ui_print "   "
ui_print "   "
chmod -R 0777 /data/adb/modules/atlantis_thermods
}
if [[ -e /data/media/0/logz ]]; then
zegon
fi
ui_print "- Do You Want To Auto Disable GAPPS When Open A Game?"
  ui_print "    1. Yes I Want. "
  ui_print "    2. No I Dont. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 2 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD3=" ✓You Choose Yes.";ui_print "- Please Wait..."
	rm -rf /data/adb/modules/gappsauto/
	mkdir -p /data/adb/modules/gappsauto/
 unzip -o "$ZIPFILE" 'GAPPS' -d /data/adb/modules/gappsauto/ >&2
tar -xf /data/adb/modules/gappsauto/GAPPS -C /data/adb/modules/gappsauto/
rm /data/adb/modules/gappsauto/GAPPS ; FCTEXTAD2b="✅ Auto E/D GAPPS Installed Successfully."; ;;
	2 ) FCTEXTAD3=""; FCTEXTAD2b="❌ 𝑆𝑘𝑖𝑝.";;
esac
sleep 1
	unzip -o "$ZIPFILE" 'Servico.sh' -d $MODPATH >&2
	mv $MODPATH/Servico.sh $MODPATH/service.sh
ui_print "- $FCTEXTAD2b "
ui_print "   "
ui_print "   "
pols() {
ui_print "- Rosemary Detected"
ui_print "- Do You Want To Install Special Touch Improve? 
[EXPERIMENT]"
  ui_print " 1. Yes I Want"
  ui_print " 2. No, I Dont"
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
tar -xf $MODPATH/Prop -C $MODPATH/
rm $MODPATH/Prop
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 2 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD0="✅ Special Touch Improve Successfully Installed.";	rm -rf /data/adb/modules/TouchOffset
mkdir -p /data/adb/modules/TouchOffset/
unzip -o "$ZIPFILE" 'Offset' -d /data/adb/modules/TouchOffset/ >&2
tar -xf /data/adb/modules/TouchOffset/Offset -C /data/adb/modules/TouchOffset/
rm /data/adb/modules/TouchOffset/Offset ;;
	2 ) FCTEXTAD0="❌ 𝑆𝑘𝑖𝑝. "; ;;
esac
sleep 1
ui_print "- $FCTEXTAD0 "
}
if [[ "$(resetprop ro.product.bootimage.model)" == "rosemary" ]]; then
pols
fi
kcal() {
ui_print "   "
ui_print "   "
ui_print "- 🛡️𝙆𝘾𝘼𝙇 𝙋𝙧𝙚𝙨𝙚𝙩🛡️"
  ui_print "     1. 𝙰𝙸𝙾 𝙰𝚖𝚘𝚕𝚎𝚍 (𝙱𝚞𝚛𝚗𝚒𝚗 𝙵𝚒𝚡 𝚁𝚎𝚌𝚘𝚖𝚖𝚎𝚗𝚍𝚎𝚍) "
  ui_print "     2. 𝙰𝙸𝙾 𝙱𝚛𝚒𝚐𝚑𝚝 "
  ui_print "     3. 𝙰𝙸𝙾 𝙱𝚛𝚒𝚐𝚑𝚝 2 "
  ui_print "     4. 𝙰𝙸𝙾 𝙳𝚎𝚎𝚙 "
  ui_print "     5. 𝙳𝚎𝚎𝚙 𝙱𝚕𝚊𝚌𝚔 𝙲𝚘𝚕𝚘𝚛𝚏𝚞𝚕 (𝙱𝚞𝚛𝚗𝚒𝚗 𝙵𝚒𝚡 𝚁𝚎𝚌𝚘𝚖𝚖𝚎𝚗𝚍𝚎𝚍) "
  ui_print "     6. 𝙴𝚡𝚝𝚛𝚎𝚖𝚎 𝙲𝚘𝚘𝚕 "
  ui_print "     7. 𝙵𝚊𝚔𝚎 𝙰𝚖𝚘𝚕𝚎𝚍 (𝙱𝚞𝚛𝚗𝚒𝚗 𝙵𝚒𝚡 𝚁𝚎𝚌𝚘𝚖𝚖𝚎𝚗𝚍𝚎𝚍) "
  ui_print "     8. 𝙷𝚊𝚛𝚕𝚎𝚢 𝚃𝚎𝚌𝚑 "
  ui_print "     9. 𝙾𝚋𝚜𝚊𝚗𝚒𝚝𝚢 "
  ui_print "    10. 𝙿𝚎𝚛𝚏𝚎𝚌𝚝𝚒𝚘𝚗 "
  ui_print "    11. 𝚅𝚘𝚖𝚎𝚛 𝙱𝚛𝚒𝚐𝚑𝚝 𝙱𝚊𝚕𝚊𝚗𝚌𝚎 "
  ui_print "    12. 𝚆𝚊𝚛𝚖 𝙰𝚖𝚘𝚕𝚎𝚍 (𝙱𝚞𝚛𝚗𝚒𝚗 𝙵𝚒𝚡 𝚁𝚎𝚌𝚘𝚖𝚖𝚎𝚗𝚍𝚎𝚍) "
  ui_print "    13. 𝙳𝚘𝚗'𝚝 𝚄𝚜𝚎 𝙺𝙲𝚊𝚕 𝙰𝚍𝚍-𝚘𝚗 "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗞𝗖𝗮𝗹 𝗖𝗼𝗻𝗳𝗶𝗴:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 13 ]; then
		AL=1
	fi
done
#
case $AL in
1 ) FCTEXTAD3=" ✓You Choose."; mv $MODPATH/00aionature.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ; FCTEXTAD2b="✅ 𝐴𝐼𝑂 𝐴𝑚𝑜𝑙𝑒𝑑."; ;;
	2 ) FCTEXTAD3=""; mv $MODPATH/00aiobright.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ;FCTEXTAD2b="✅ 𝐴𝐼𝑂 𝐵𝑟𝑖𝑔𝒉𝑡";;
	3 ) FCTEXTAD3="";mv $MODPATH/00aiobright2.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ; FCTEXTAD2b="✅ 𝐴𝐼𝑂 𝐵𝑟𝑖𝑔𝒉𝑡 2.";;
   4 ) FCTEXTAD3=""; mv $MODPATH/00aiodeep.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh; FCTEXTAD2b="✅ 𝐴𝐼𝑂 𝐷𝑒𝑒𝑝.";;
   5 ) FCTEXTAD3=""; mv $MODPATH/00aioblack.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh; FCTEXTAD2b="✅ 128 Bit Installed Successfully.";;
   6 ) FCTEXTAD3=""; mv $MODPATH/00aioextreme.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ; FCTEXTAD2b="✅ 𝐷𝑒𝑒𝑝 𝐵𝑙𝑎𝑐𝑘 𝐶𝑜𝑙𝑜𝑟𝑓𝑢𝑙.";;
7 ) FCTEXTAD3=""; mv $MODPATH/00aiofakeamoled.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ; FCTEXTAD2b="✅ 𝐸𝑥𝑡𝑟𝑒𝑚𝑒 𝐶𝑜𝑜𝑙";;
8 ) FCTEXTAD3=""; mv $MODPATH/00aiohtech.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ; FCTEXTAD2b="✅ 𝐹𝑎𝑘𝑒 𝐴𝑚𝑜𝑙𝑒𝑑";;
9 ) FCTEXTAD3=""; mv $MODPATH/00aioobsanity.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ; FCTEXTAD2b="✅ 𝑂𝑏𝑠𝑎𝑛𝑖𝑡𝑦";;
  10 ) FCTEXTAD3=""; mv $MODPATH/00aioperfect.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ; FCTEXTAD2b="✅ 𝑃𝑒𝑟𝑓𝑒𝑐𝑡𝑖𝑜𝑛";;
11 ) FCTEXTAD3=""; mv $MODPATH/00aiovomerb.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ; FCTEXTAD2b="✅ 𝑉𝑜𝑚𝑒𝑟 𝐵𝑟𝑖𝑔𝒉𝑡 𝐵𝑎𝑙𝑎𝑛𝑐𝑒";;
12 ) FCTEXTAD3=""; mv $MODPATH/00aiowarmamoled.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ; FCTEXTAD2b="✅ 𝑊𝑎𝑟𝑚 𝐴𝑚𝑜𝑙𝑒𝑑";;
13 ) FCTEXTAD3=""; mv $MODPATH/00aiovomerb.sh $MODPATH/config/00aiokcal.sh
sh $MODPATH/config/00aiokcal.sh ; FCTEXTAD2b="❌ 𝐷𝑜𝑛'𝑡 𝑈𝑠𝑒 𝐾𝐶𝑎𝑙 𝐴𝑑𝑑-𝑜𝑛";;
esac
sleep 1
ui_print "- $FCTEXTAD2b "
ui_print "   "
ui_print "   "
  ui_print "- 🛡️𝙨𝙍𝙂𝘽 𝙊𝙥𝙩𝙞𝙤𝙣𝙨🛡️"
  ui_print "    1. 𝙴𝚗𝚊𝚋𝚕𝚎 𝚜𝚁𝙶𝙱 "
  ui_print "    2. 𝙳𝚒𝚜𝚊𝚋𝚕𝚎 𝚜𝚁𝙶𝙱 "
  ui_print "    3. 𝙳𝚘𝚗'𝚝 𝚄𝚜𝚎 𝚜𝚁𝙶𝙱 𝙰𝚍𝚍-𝚘𝚗 "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝘀𝗥𝗚𝗕 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
SR=1
while true; do
	ui_print "  $SR"
	if $VKSEL; then
		SR=$((SR + 1))
	else 
		break
	fi
	if [ $SR -gt 3 ]; then
		SR=1
	fi
done
ui_print "  𝘀𝗥𝗚𝗕 𝗢𝗽𝘁𝗶𝗼𝗻𝘀: $SR"
#
#
case $SR in
	1 ) FCTEXTAD10="✅ 𝐸𝑛𝑎𝑏𝑙𝑒 𝑠𝑅𝐺𝐵"; cp -af $MODPATH/AIO/srgb_on $MODPATH/config/srgb.sh;;
	2 ) FCTEXTAD10="📵 𝐷𝑖𝑠𝑎𝑏𝑙𝑒 𝑠𝑅𝐺𝐵"; cp -af $MODPATH/AIO/srgb_off $MODPATH/config/srgb.sh;;
	3 ) FCTEXTAD10="❌ 𝐷𝑜𝑛'𝑡 𝑈𝑠𝑒 𝑠𝑅𝐺𝐵 𝐴𝑑𝑑-𝑜𝑛";rm -rf /data/adb/modules/kcal ;;
esac
ui_print "  $FCTEXTAD10 "
mv $MODPATH/config /data/adb/modules/kcal/config/
}
if [[ -e /sys/devices/platform/kcal_ctrl.0 ]]
then
kcal
else 
rm -rf /data/adb/modules/kcal
fi
rm -rf $MODPATH/config
rm -rf $MODPATH/AIO
pubg() {
ui_print "   "
ui_print "   "
ui_print "- PUBG GLOBAL DETECTED."
ui_print "- Do You Want To Delete PUBG Shader + Skin To Make PUBG Run Smoothly? 
[EXPERIMENT]"
  ui_print " 1. Yes I Want"
  ui_print " 2. No, I Dont"
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
tar -xf $MODPATH/Prop -C $MODPATH/
rm $MODPATH/Prop
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 2 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD0="✅ PUBG Optimization Successfully Executed.";	rm /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/ODPaks/*.pak
	chmod -R 0555 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/ODPaks/ ;;
	2 ) FCTEXTAD0="❌ 𝑆𝑘𝑖𝑝. "; ;;
esac
sleep 1
ui_print "- $FCTEXTAD0 "
}
if [ -d /data/media/0/Android/data/com.tencent.ig ]; then
pubg
fi
profile() {
if getprop ro.product.cpu.abi | grep -q "v8a"; then bit=i64; else bit=i32; fi
ui_print "   "
ui_print "   "
ui_print "- Surface Flinger Profiler"
ui_print "- Select Your Profile"
  ui_print " 1. Hybrid Profile"
  ui_print " 2. GPU Profile"
  ui_print " 3. CPU Profile"
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
tar -xf $MODPATH/Prop -C $MODPATH/
rm $MODPATH/Prop
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 3 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD0="✅ Hybrid Profile Has Been Installed."; mkdir -p /data/adb/modules/surfaceflinger_profile/
unzip -o "$ZIPFILE" 'Overlay' -d /data/adb/modules/surfaceflinger_profile/ >&2
tar -xf /data/adb/modules/surfaceflinger_profile/Overlay -C /data/adb/modules/surfaceflinger_profile/
	echo "service call SurfaceFlinger 1006 $bit 1 $bit 1" > /data/adb/modules/surfaceflinger_profile/service.sh  ;;
	2 ) FCTEXTAD0="✅ GPU Profile Has Been Installed.";	mkdir -p /data/adb/modules/surfaceflinger_profile/
unzip -o "$ZIPFILE" 'Overlay' -d /data/adb/modules/surfaceflinger_profile/ >&2
tar -xf /data/adb/modules/surfaceflinger_profile/Overlay -C /data/adb/modules/surfaceflinger_profile/
	echo "service call SurfaceFlinger 1006 $bit 0 $bit 1" > /data/adb/modules/surfaceflinger_profile/service.sh ;;
		3 ) FCTEXTAD0="✅ CPU Profile Has Been Installed.";	mkdir -p /data/adb/modules/surfaceflinger_profile/
unzip -o "$ZIPFILE" 'Overlay' -d /data/adb/modules/surfaceflinger_profile/ >&2
tar -xf /data/adb/modules/surfaceflinger_profile/Overlay -C /data/adb/modules/surfaceflinger_profile/
		echo "service call SurfaceFlinger 1006 $bit 1 $bit 0" > /data/adb/modules/surfaceflinger_profile/service.sh ;;
	4 ) FCTEXTAD0="❌ 𝑆𝑘𝑖𝑝. ";rm -rf /data/adb/modules/surfaceflinger_profile/ ;;
esac
sleep 1
ui_print "- $FCTEXTAD0 "
}
if [ $(service check SurfaceFlinger | grep -c 'found') -eq 1 ]; then ui_print "- SurfaceFlinger Service Detected."
profile; fi
rm /data/adb/modules/surfaceflinger_profile/Overlay
ui_print ""
ui_print "   "
ui_print "- Bit Changer  "
  ui_print "    1. 8 Bit "
  ui_print "    2. 16 Bit "
  ui_print "    3. 32 Bit"
  ui_print "    4. 64 Bit"
  ui_print "    5. 128 Bit "
  ui_print "    6. Skip "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 6 ]; then
		AL=1
	fi
done
#
case $AL in
1 ) FCTEXTAD3=" ✓You Choose."; sed -i 's/16bpp/8bpp/g' $MODPATH/system.prop ; FCTEXTAD2b="✅ 8 Bit Installed Successfully."; ;;
	2 ) FCTEXTAD3=""; FCTEXTAD2b="✅ 16 Bit Installed Successfully.";;
	3 ) FCTEXTAD3="";sed -i 's/16bpp/32bpp/g' $MODPATH/system.prop ; FCTEXTAD2b="✅ 32 Bit Installed Successfully.";;
   4 ) FCTEXTAD3=""; sed -i 's/16bpp/64bpp/g' $MODPATH/system.prop; FCTEXTAD2b="✅ 64 Bit Installed Successfully.";;
   5 ) FCTEXTAD3=""; sed -i 's/16bpp/128bpp/g' $MODPATH/system.prop; FCTEXTAD2b="✅ 128 Bit Installed Successfully.";;
   6 ) FCTEXTAD3=""; sed -i '/persist.sys.use_16bpp_alpha/d' $MODPATH/system.prop ; FCTEXTAD2b="❌ 𝑆𝑘𝑖𝑝.";;
  
esac
sleep 1
ui_print "- $FCTEXTAD2b "
ui_print "   "
ui_print "   "
ui_print "- Choose Your Render Composition"
  ui_print "    1. MDP (100% CPU Rendering) "
  ui_print "    2. GPU (100% GPU Rendering) "
  ui_print "    3. C2D (25% CPU + 75% GPU Rendering)"
  ui_print "    4. DYN (50% CPU + 50% GPU Rendering) "
  ui_print "    5. Skip "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 5 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD3=" ✓You Choose."; sed -i 's/#3/mdp/g' $MODPATH/system.prop ; FCTEXTAD2b="✅ MDP Composition Installed Successfully."; ;;
	2 ) FCTEXTAD3="";sed -i 's/#3/gpu/g' $MODPATH/system.prop ; FCTEXTAD2b="✅ GPU Composition Installed Successfully.";;
	3 ) FCTEXTAD3="";sed -i 's/#3/c2d/g' $MODPATH/system.prop ; FCTEXTAD2b="✅ C2D Composition Installed Successfully.";;
   4 ) FCTEXTAD3=""; sed -i 's/#3/dyn/g' $MODPATH/system.prop ; FCTEXTAD2b="✅ DYN Composition Installed Successfully.";;
   5 ) FCTEXTAD3=""; sed -i '/debug.composition.type=#3/d; /persist.sys.composition.type=#3/d' $MODPATH/system.prop ; FCTEXTAD2b="❌ 𝑆𝑘𝑖𝑝.";;
esac
sleep 1
ui_print "- $FCTEXTAD2b "
ui_print "   "
ui_print "   "
ui_print "- Choose Your Kind of Rendering"
  ui_print "    1. OpenGL (Not Work For Some Devices) "
  ui_print "    2. SkiaGL "
  ui_print "    3. Vulkan (Not Work For Some Devices) "
  ui_print "    4. Skia Vulkan "
  ui_print "    5. Skip "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 5 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD3=" ✓You Choose."; sed -i 's/#1/false/g' $MODPATH/system.prop
	sed -i 's/#2/opengl/g' $MODPATH/system.prop ; FCTEXTAD2b="✅ OpenGL Rendering Installed Successfully."; ;;
	2 ) FCTEXTAD3="";sed -i 's/#1/false/g' $MODPATH/system.prop
sed -i 's/#2/skiagl/g' $MODPATH/system.prop ; FCTEXTAD2b="✅ SkiaGL Rendering Installed Successfully.";;
	3 ) FCTEXTAD3="";sed -i 's/#2/vulkan/g' $MODPATH/system.prop 
sed -i 's/#1/true/g' $MODPATH/system.prop ; FCTEXTAD2b="✅ Vulkan Rendering Installed Successfully.";;
   4 ) FCTEXTAD3=""; sed -i 's/#1/true/g' $MODPATH/system.prop
sed -i 's/#2/skiavk/g' $MODPATH/system.prop; FCTEXTAD2b="✅ Skia Vulkan Rendering Installed Successfully.";;
   5 ) FCTEXTAD3=""; sed -i '/ro\.hwui\.use_vulkan=#1/d; /hwui\.renderer=#2/d; /debug\.hwui\.renderer=#2/d' $MODPATH/system.prop ; FCTEXTAD2b="❌ 𝑆𝑘𝑖𝑝.";;
  
esac
sleep 1
ui_print "- $FCTEXTAD2b "
find /data/adb/modules_update/Z907L -type f -size 0 -delete
sleep 2
cp /data/adb/modules_update/Z907L/Atlantis-Remover.zip /data/media/0
ui_print ""
ui_print "***NOTE****"
ui_print "- IF YOU GET BOOTLOOP, JUST FLASH ATLANTIS-REMOVER.ZIP"
ui_print "- IN YOUR RECOVERY. THE FILE AUTOMATIC ADD IN YOUR"
ui_print "- INTERNAL STORAGE"
ui_print ""
sleep 2
unzip -o "$ZIPFILE" 'sda' -d $MODPATH/system/bin >&2
set_perm_recursive $MODPATH 0 0 0777 0777
pm install $MODPATH/toast.apk
  set_perm_recursive /data/adb/modules/gunlocker 0 0 0777 0777
  set_perm_recursive /data/adb/modules/aaddon 0 0 0777 0777
set_perm /data/adb/modules/aaddon/system/bin/gmsc 0 2000 0755
sleep 1
sleep 2
rm $MODPATH/Atlantis-Remover.zip
rm $MODPATH/system-torso/
rm $MODPATH/Addon
rm $MODPATH/Reset
rm $MODPATH/toast.apk
rm $MODPATH/Auto
ui_print "   "
ui_print "   "
ui_print "- Do You Want To Installing Atlantis Busybox?"
  ui_print "    1. Yes I Want. "
  ui_print "    2. No I Dont. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 2 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD3=" ✓You Choose Yes.";rm -rf /data/adb/modules/busybox-ndk
rm -rf /data/adb/modules/busybox-brutal
rm -rf /data/adb/modules/Builtin-BusyBox
ui_print "Please Wait..."
busybox; FCTEXTAD2b="Done✅"; ;;
	2 ) FCTEXTAD3=""; FCTEXTAD2b="❌ 𝑆𝑘𝑖𝑝.";;
esac
sleep 2
ui_print "- $FCTEXTAD2b "
ui_print "   "
ui_print "   "
ui_print "- Do You Want To Activating Atlantis After This Installation (Without Reboot)?
Tweaks Like Unlocker/Change Rendering/ZRAM-CHANGER/SWAP-RAM-CHANGER Will Not Work."
  ui_print "    1. Yes I Want. (3-5 Minutes Process) "
  ui_print "    2. No I Dont. "
  ui_print "   "
ui_print "  𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝘄𝗲𝗮𝗸𝘀 𝗢𝗽𝘁𝗶𝗼𝗻𝘀:"
AL=1
while true; do
	ui_print "  $AL"
	if $VKSEL; then
		AL=$((AL + 1))
	else 
		break
	fi
	if [ $AL -gt 2 ]; then
		AL=1
	fi
done
#
case $AL in
	1 ) FCTEXTAD3=" ✓You Choose Yes.";
	ui_print "Please Wait... (Just Ignore NULL Output)"
	cp -R /data/adb/modules_update/Z907L/system/bin /system/
	cp /data/adb/modules/gappsauto/system/bin /system
	cp /data/adb/modules/aaddon/system/bin/QTI /system/bin/
	cp /data/adb/modules/autocpu/system/bin /system
	cp /data/adb/modules/angle/system/bin /system
	 sh /data/adb/modules_update/Z907L/post-fs-data.sh
	sda
	 sh /data/adb/modules/Builtin-BusyBox/post-fs-data.sh
	sh /data/adb/modules/Builtin-BusyBox/service.sh
	sh /data/adb/modules/TouchOffset/service.sh
	/data/adb/modules/atlantis_thermods/Atlantis
	/data/adb/modules/atlantis_thermods/local
	/data/adb/modules_update/Z907L/Activity
	sh /data/adb/modules/surfaceflinger_profile/service.sh
	cp -R /data/adb/modules/cpu_runtime/system/bin /system
	Remove
	@Z907L
/data/adb/modules_update/Z907L/Atlantis-Core; FCTEXTAD2b="Done✅
- You Can Close Termux APP Now."; ;;
	2 ) FCTEXTAD3=""; FCTEXTAD2b="❌ 𝑆𝑘𝑖𝑝.
- Now You Can Reboot Your Devices✅";;
esac
sleep 2
ui_print "- $FCTEXTAD2b "
QTI &
AI &
ui_print "   "
ui_print "   "
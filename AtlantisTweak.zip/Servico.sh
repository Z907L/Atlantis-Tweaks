#!/bin/sh
MODDIR=${0%/*}
$MODDIR/Activity
while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; done
AI &
sda
ZRAMSIZE=0
SWAPSIZE=0
# Zram functions
disable_zram()
{
    echo "3" > /proc/sys/vm/drop_caches
    swapoff /dev/block/zram0
    echo "0" > /sys/class/zram-control/hot_remove
}

change_zram()
{
    sleep 5
    echo "3" > /proc/sys/vm/drop_caches
    swapoff /dev/block/zram0
    echo "1" > /sys/block/zram0/reset
    echo "0" > /sys/block/zram0/disksize
    echo "$ZRAMSIZE" > /sys/block/zram0/disksize
    mkswap /dev/block/zram0
    swapon /dev/block/zram0
}

# Swap functions
change_swap()
{
    if [ ! -e $MODDIR/swapram_installed ]; then
      if test -f "/data/swap"; then
        rm -f /data/swap
        dd if=/dev/zero of=/data/swap bs=1024 count=$SWAPSIZE
        mkswap /data/swap
        swapon /data/swap
      else
        dd if=/dev/zero of=/data/swap bs=1024 count=$SWAPSIZE
        mkswap /data/swap
        swapon /data/swap
      fi
      touch $MODDIR/swapram_installed
    else
      if test -f "/data/swap"; then
        swapon /data/swap
      else
        dd if=/dev/zero of=/data/swap bs=1024 count=$SWAPSIZE
        mkswap /data/swap
        swapon /data/swap
      fi
    fi
}
stop logd
stop perfd
stop tcpdump
stop cnss_diag
stop statsd
stop traced
stop idd-logreader
stop idd-logreadermain
stop vendor.perfservice
stop miuibooster
stop system_perf_init
#change_zram
#change_swap
$MODDIR/Atlantis-Core

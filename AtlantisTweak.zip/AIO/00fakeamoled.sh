#!/system/bin/sh
# Fake Amoled

echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '225 225 237' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '264' > /sys/devices/platform/kcal_ctrl.0/kcal_cont
echo '0' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '35' > /sys/devices/platform/kcal_ctrl.0/kcal_min
echo '277' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '250' > /sys/devices/platform/kcal_ctrl.0/kcal_val

echo "Fake Amoled KCAL Tweaks Excecuted on $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/kcal_preset.log
echo "" >> /storage/emulated/0/kcal_preset.log
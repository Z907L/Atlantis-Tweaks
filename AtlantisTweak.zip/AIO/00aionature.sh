#!/system/bin/sh
# AIO Nature

echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '240 256 256' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '264' > /sys/devices/platform/kcal_ctrl.0/kcal_cont
echo '0' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '35' > /sys/devices/platform/kcal_ctrl.0/kcal_min
echo '290' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '242' > /sys/devices/platform/kcal_ctrl.0/kcal_val

echo "AIO Amoled KCAL Tweaks Excecuted on $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/kcal_preset.log
echo "" >> /storage/emulated/0/kcal_preset.log
#!/system/bin/sh
# AIO Bright

echo "1" > /sys/devices/platform/kcal_ctrl.0/kcal_enable
echo '237 239 247' > /sys/devices/platform/kcal_ctrl.0/kcal
echo '243' > /sys/devices/platform/kcal_ctrl.0/kcal_cont
echo '0' > /sys/devices/platform/kcal_ctrl.0/kcal_hue
echo '35' > /sys/devices/platform/kcal_ctrl.0/kcal_min
echo '275' > /sys/devices/platform/kcal_ctrl.0/kcal_sat
echo '277' > /sys/devices/platform/kcal_ctrl.0/kcal_val

echo "AIO Bright KCAL Tweaks Excecuted on $(date +"%d-%m-%Y %r" )" >> /storage/emulated/0/kcal_preset.log
echo "" >> /storage/emulated/0/kcal_preset.log